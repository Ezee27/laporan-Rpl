<!DOCTYPE html>
<html>
<head>
    <title>Pengingat Jadwal Kuliah</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f6f8;
            padding: 20px;
        }
        nav a {
            margin-right: 10px;
            text-decoration: none;
            color: #0066cc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
        }
        th {
            background: #eee;
        }
    </style>
</head>
<body>

<nav>
    <a href="index.php">Home</a>
    <a href="users.php">Users</a>
    <a href="dosen.php">Dosen</a>
    <a href="mata_kuliah.php">Mata Kuliah</a>
    <a href="jadwal.php">Jadwal</a>
    <a href="tugas.php">Tugas</a>
    <a href="pengingat.php">Pengingat</a>
    <a href="notifikasi.php">Notifikasi</a>
</nav>

<hr>
