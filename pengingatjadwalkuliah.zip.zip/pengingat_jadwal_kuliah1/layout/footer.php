<hr>
<p style="text-align:center;">
    &copy; 2025 - Pengingat Jadwal Kuliah
</p>

</body>
</html>
