<?php
session_start();
include "../config/database.php";

/* =======================
   CEK LOGIN & ROLE
======================= */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'mahasiswa') {
    header("Location: ../auth/login.php");
    exit;
}

/* =======================
   DATA USER
======================= */
$namaUser = $_SESSION['user']['nama'];

/* =======================
   HITUNG DATA
======================= */
$jumlahMatkul = $conn->query("SELECT COUNT(*) FROM mata_kuliah")->fetchColumn();
$jumlahJadwal = $conn->query("SELECT COUNT(*) FROM jadwal_kuliah")->fetchColumn();
$jumlahTugas  = $conn->query("SELECT COUNT(*) FROM tugas")->fetchColumn();

/* =======================
   HARI INI (INDONESIA)
======================= */
$hariIni = date('l');
$hariIndo = [
    'Monday'    => 'Senin',
    'Tuesday'   => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday'  => 'Kamis',
    'Friday'    => 'Jumat',
    'Saturday'  => 'Sabtu',
    'Sunday'    => 'Minggu'
];
$hari = $hariIndo[$hariIni];

/* =======================
   JADWAL HARI INI
======================= */
$stmtJadwal = $conn->prepare("
    SELECT mk.nama_matkul, jk.jam_mulai, jk.jam_selesai, jk.ruangan
    FROM jadwal_kuliah jk
    JOIN mata_kuliah mk ON jk.id_matkul = mk.id_matkul
    WHERE jk.hari = ?
    ORDER BY jk.jam_mulai ASC
");
$stmtJadwal->execute([$hari]);
$jadwalHariIni = $stmtJadwal->fetchAll(PDO::FETCH_ASSOC);

/* =======================
   TUGAS TERDEKAT
======================= */
$stmtTugas = $conn->query("
    SELECT mk.nama_matkul, t.judul_tugas, t.deadline
    FROM tugas t
    JOIN mata_kuliah mk ON t.id_matkul = mk.id_matkul
    ORDER BY t.deadline ASC
    LIMIT 5
");
$tugas = $stmtTugas->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Mahasiswa</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">

<style>
.card-box{
    border-radius:12px;
    padding:20px;
    color:#fff;
}
.bg-blue{background:linear-gradient(135deg,#1e88e5,#42a5f5);}
.bg-green{background:linear-gradient(135deg,#43a047,#66bb6a);}
.bg-orange{background:linear-gradient(135deg,#fb8c00,#ffa726);}

.time-box{
    background:#fff;
    border-radius:12px;
    padding:15px 20px;
    box-shadow:0 2px 6px rgba(0,0,0,.08);
}
#jamSekarang{
    font-size:26px;
    font-weight:bold;
    color:#0d6efd;
}
</style>
</head>

<body>

<?php include "../partials/sidebar.php"; ?>

<div class="content">

<h3 class="mb-3">👋 Selamat datang, <b><?= $namaUser ?></b></h3>

<!-- WAKTU -->
<div class="time-box mb-4 d-flex justify-content-between align-items-center">
    <div>
        <small class="text-muted">📅 Hari & Tanggal</small>
        <h5 id="tanggalSekarang"></h5>
    </div>
    <div class="text-end">
        <small class="text-muted">⏰ Jam</small>
        <div id="jamSekarang"></div>
    </div>
</div>

<!-- STATISTIK -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card-box bg-blue">
            <h6>Mata Kuliah</h6>
            <h2><?= $jumlahMatkul ?></h2>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-box bg-green">
            <h6>Jadwal Kuliah</h6>
            <h2><?= $jumlahJadwal ?></h2>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-box bg-orange">
            <h6>Tugas</h6>
            <h2><?= $jumlahTugas ?></h2>
        </div>
    </div>
</div>

<!-- JADWAL -->
<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        📅 Jadwal Hari Ini (<?= $hari ?>)
    </div>
    <div class="card-body">
        <?php if (!$jadwalHariIni): ?>
            <div class="alert alert-warning">Tidak ada jadwal hari ini</div>
        <?php else: ?>
        <table class="table table-bordered">
            <tr>
                <th>Mata Kuliah</th>
                <th>Jam</th>
                <th>Ruangan</th>
            </tr>
            <?php foreach ($jadwalHariIni as $j): ?>
            <tr>
                <td><?= $j['nama_matkul'] ?></td>
                <td><?= $j['jam_mulai'] ?> - <?= $j['jam_selesai'] ?></td>
                <td><?= $j['ruangan'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
</div>

<!-- TUGAS -->
<div class="card">
    <div class="card-header bg-dark text-white">
        ⏰ Tugas Terdekat
    </div>
    <div class="card-body">
        <?php if (!$tugas): ?>
            <div class="alert alert-success">Tidak ada tugas</div>
        <?php else: ?>
        <table class="table table-striped">
            <tr>
                <th>Mata Kuliah</th>
                <th>Judul</th>
                <th>Deadline</th>
            </tr>
            <?php foreach ($tugas as $t): ?>
            <tr>
                <td><?= $t['nama_matkul'] ?></td>
                <td><?= $t['judul_tugas'] ?></td>
                <td><?= $t['deadline'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
</div>

</div>

<script>
function updateWaktu(){
    const hari=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
    const bulan=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
    const now=new Date();

    document.getElementById("tanggalSekarang").innerText =
        hari[now.getDay()] + ", " + now.getDate() + " " + bulan[now.getMonth()] + " " + now.getFullYear();

    document.getElementById("jamSekarang").innerText =
        now.toLocaleTimeString("id-ID") + " WIB";
}
setInterval(updateWaktu,1000);
updateWaktu();
</script>

</body>
</html>
