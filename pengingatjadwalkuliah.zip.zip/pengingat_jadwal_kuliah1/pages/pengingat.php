<?php
session_start();
include "../config/database.php";

// CEK LOGIN
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

// ==========================
// KONVERSI HARI (AUTO DETECT)
// ==========================
$hariInggris = date('l');
$hariIndo = [
    'Monday'    => 'Senin',
    'Tuesday'   => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday'  => 'Kamis',
    'Friday'    => 'Jumat',
    'Saturday'  => 'Sabtu',
    'Sunday'    => 'Minggu'
];
$hari = $hariIndo[$hariInggris];

// JAM SEKARANG
$jamSekarang = date('H:i');

// ==========================
// AMBIL JADWAL HARI INI
// ==========================
$stmt = $conn->prepare("
    SELECT 
        mk.kode_matkul,
        mk.nama_matkul,
        jk.jam_mulai,
        jk.jam_selesai,
        jk.ruangan
    FROM jadwal_kuliah jk
    JOIN mata_kuliah mk ON jk.id_matkul = mk.id_matkul
    WHERE jk.hari = ?
    ORDER BY jk.jam_mulai ASC
");
$stmt->execute([$hari]);
$jadwalHariIni = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pengingat Jadwal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">

<style>
.status {
    padding:6px 12px;
    border-radius:20px;
    font-size:13px;
    font-weight:600;
}
.status-coming { background:#e3f2fd; color:#0d6efd; }
.status-now { background:#fff3cd; color:#856404; }
.status-done { background:#e8f5e9; color:#2e7d32; }
</style>
</head>

<body>

<?php include "../partials/sidebar.php"; ?>

<div class="content">

<h3 class="mb-1">🔔 Pengingat Jadwal Kuliah</h3>
<p class="text-muted mb-4">
    Hari ini: <b><?= $hari ?></b> | Jam sekarang: <b><?= $jamSekarang ?> WIB</b>
</p>

<div class="card">
<div class="card-body">

<?php if (count($jadwalHariIni) == 0): ?>
    <div class="alert alert-warning">
        Tidak ada jadwal kuliah hari ini
    </div>
<?php else: ?>

<table class="table table-bordered align-middle">
<thead class="table-primary">
<tr>
    <th>No</th>
    <th>Mata Kuliah</th>
    <th>Jam</th>
    <th>Ruangan</th>
    <th>Status</th>
</tr>
</thead>
<tbody>

<?php
$no = 1;
foreach ($jadwalHariIni as $j):

    // ==========================
    // LOGIKA STATUS JAM
    // ==========================
    if ($jamSekarang < $j['jam_mulai']) {
        $status = "<span class='status status-coming'>⏳ Akan Datang</span>";
    } elseif ($jamSekarang >= $j['jam_mulai'] && $jamSekarang <= $j['jam_selesai']) {
        $status = "<span class='status status-now'>🔔 Sedang Berlangsung</span>";
    } else {
        $status = "<span class='status status-done'>✅ Selesai</span>";
    }
?>

<tr>
    <td><?= $no++ ?></td>
    <td>
        <b><?= $j['kode_matkul'] ?></b><br>
        <small class="text-muted"><?= $j['nama_matkul'] ?></small>
    </td>
    <td><?= $j['jam_mulai'] ?> - <?= $j['jam_selesai'] ?></td>
    <td><?= $j['ruangan'] ?></td>
    <td><?= $status ?></td>
</tr>

<?php endforeach; ?>

</tbody>
</table>

<?php endif; ?>

</div>
</div>

</div>

</body>
</html>
