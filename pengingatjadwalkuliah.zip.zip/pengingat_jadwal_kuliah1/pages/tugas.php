<?php
session_start();
include "../config/database.php";

// CEK LOGIN
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id_user = $_SESSION['user']['id_user'];

// AMBIL DATA TUGAS
$stmt = $conn->prepare("
    SELECT 
        t.id_tugas,
        t.judul_tugas,
        t.deadline,
        mk.kode_matkul,
        mk.nama_matkul
    FROM tugas t
    JOIN mata_kuliah mk ON t.id_matkul = mk.id_matkul
    ORDER BY t.deadline ASC
");
$stmt->execute();
$tugas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Tugas</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<?php include "../partials/sidebar.php"; ?>

<div class="content">

<h3 class="mb-4">📝 Daftar Tugas</h3>

<table class="table table-bordered bg-white">
<thead class="table-primary">
<tr>
    <th>No</th>
    <th>Mata Kuliah</th>
    <th>Judul Tugas</th>
    <th>Deadline</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
</thead>
<tbody>

<?php
$no = 1;
foreach ($tugas as $t):

    // CEK STATUS UPLOAD
    $cek = $conn->prepare("
        SELECT 1 FROM pengumpulan_tugas
        WHERE id_user = ? AND id_tugas = ?
    ");
    $cek->execute([$id_user, $t['id_tugas']]);
    $sudahUpload = $cek->fetch();
?>

<tr>
    <td><?= $no++ ?></td>
    <td><?= $t['kode_matkul'] ?> - <?= $t['nama_matkul'] ?></td>
    <td><?= $t['judul_tugas'] ?></td>
    <td><?= date('d-m-Y H:i', strtotime($t['deadline'])) ?></td>
    <td>
        <?php if ($sudahUpload): ?>
            <span class="badge bg-success">Sudah Upload</span>
        <?php else: ?>
            <span class="badge bg-danger">Belum Upload</span>
        <?php endif; ?>
    </td>
    <td>
        <a href="tugas_upload.php?id=<?= $t['id_tugas'] ?>" class="btn btn-sm btn-primary">
            Upload
        </a>
        <a href="tugas_riwayat.php?id=<?= $t['id_tugas'] ?>" class="btn btn-sm btn-secondary">
            Riwayat
        </a>
    </td>
</tr>

<?php endforeach; ?>

</tbody>
</table>

</div>
</body>
</html>
