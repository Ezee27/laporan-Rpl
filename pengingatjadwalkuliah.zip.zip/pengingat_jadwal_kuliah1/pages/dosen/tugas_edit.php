<?php
session_start();
include "../../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'];

// AMBIL DATA TUGAS
$stmt = $conn->prepare("
    SELECT t.*, mk.nama_matkul
    FROM tugas t
    JOIN mata_kuliah mk ON t.id_matkul = mk.id_matkul
    WHERE t.id_tugas = ?
");
$stmt->execute([$id]);
$tugas = $stmt->fetch();

if (!$tugas) {
    echo "Tugas tidak ditemukan";
    exit;
}

// UPDATE DEADLINE
if (isset($_POST['update'])) {
    $deadline = $_POST['deadline'];

    $up = $conn->prepare("UPDATE tugas SET deadline=? WHERE id_tugas=?");
    $up->execute([$deadline, $id]);

    header("Location: tugas_list.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Deadline</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">

<h4>✏️ Edit Deadline</h4>

<form method="POST">
    <div class="mb-2">
        <label>Mata Kuliah</label>
        <input class="form-control" value="<?= $tugas['nama_matkul'] ?>" readonly>
    </div>

    <div class="mb-2">
        <label>Judul Tugas</label>
        <input class="form-control" value="<?= $tugas['judul_tugas'] ?>" readonly>
    </div>

    <div class="mb-3">
        <label>Deadline Baru</label>
        <input type="datetime-local" name="deadline"
               value="<?= date('Y-m-d\TH:i', strtotime($tugas['deadline'])) ?>"
               class="form-control" required>
    </div>

    <button name="update" class="btn btn-primary">💾 Simpan</button>
    <a href="tugas_list.php" class="btn btn-secondary">Batal</a>
</form>

</div>
</body>
</html>
