<?php
session_start();
include "../../config/database.php";

/* =======================
   CEK LOGIN & ROLE DOSEN
======================= */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

$nama = $_SESSION['user']['nama'];

/* =======================
   HITUNG TUGAS DOSEN
======================= */
$jumlahTugas = $conn->query("SELECT COUNT(*) FROM tugas")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Dosen</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#f4f6f9;
    font-family:Segoe UI;
}
.card-box{
    border-radius:12px;
    padding:20px;
    color:#fff;
}
.bg-purple{
    background:linear-gradient(135deg,#6f42c1,#8e63dd);
}
.time-box{
    background:#fff;
    border-radius:12px;
    padding:15px 20px;
    box-shadow:0 2px 6px rgba(0,0,0,.08);
}
#jamSekarang{
    font-size:26px;
    font-weight:bold;
    color:#6f42c1;
}
</style>
</head>

<body>

<div class="container mt-4">

<h3 class="mb-3">👨‍🏫 Selamat datang, <b><?= $nama ?></b></h3>

<div class="time-box mb-4 d-flex justify-content-between align-items-center">
    <div>
        <small class="text-muted">📅 Hari & Tanggal</small>
        <h5 id="tanggalSekarang"></h5>
    </div>
    <div class="text-end">
        <small class="text-muted">⏰ Jam</small>
        <div id="jamSekarang"></div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card-box bg-purple">
            <h6>Total Tugas Dibuat</h6>
            <h2><?= $jumlahTugas ?></h2>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-dark text-white">
        ⚙️ Menu Dosen
    </div>
    <div class="card-body">
        <a href="tugas_buat.php" class="btn btn-primary mb-2">➕ Buat Tugas</a>
        <a href="tugas_list.php" class="btn btn-secondary mb-2">📋 Daftar Tugas</a>
    </div>
</div>

</div>

<script>
function updateWaktu(){
    const hari=["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
    const bulan=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
    const now=new Date();

    document.getElementById("tanggalSekarang").innerText =
        hari[now.getDay()] + ", " + now.getDate() + " " + bulan[now.getMonth()] + " " + now.getFullYear();

    document.getElementById("jamSekarang").innerText =
        now.toLocaleTimeString("id-ID") + " WIB";
}
setInterval(updateWaktu,1000);
updateWaktu();
</script>

</body>
</html>
