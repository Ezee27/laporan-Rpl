<?php
session_start();
include "../../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

$id = $_GET['id'];

// HAPUS RIWAYAT PENGUMPULAN (JIKA ADA)
$conn->prepare("DELETE FROM pengumpulan_tugas WHERE id_tugas=?")->execute([$id]);

// HAPUS TUGAS
$conn->prepare("DELETE FROM tugas WHERE id_tugas=?")->execute([$id]);

header("Location: tugas_list.php");
exit;
