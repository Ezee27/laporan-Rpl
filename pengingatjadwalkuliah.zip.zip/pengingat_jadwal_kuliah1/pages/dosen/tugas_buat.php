<?php
session_start();
include "../../config/database.php";

// CEK LOGIN DOSEN
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

// SIMPAN TUGAS
if (isset($_POST['simpan'])) {
    $id_matkul = $_POST['id_matkul'];
    $judul     = $_POST['judul'];
    $deadline  = $_POST['deadline'];

    $stmt = $conn->prepare("
        INSERT INTO tugas (id_matkul, judul_tugas, deadline)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$id_matkul, $judul, $deadline]);

    header("Location: tugas_list.php?msg=berhasil");
    exit;
}

// AMBIL SEMUA MATA KULIAH (TANPA FILTER)
$matkul = $conn->query("
    SELECT id_matkul, kode_matkul, nama_matkul 
    FROM mata_kuliah 
    ORDER BY nama_matkul ASC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Buat Tugas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">

<h4 class="mb-3">➕ Buat Tugas Baru</h4>

<form method="POST">

    <div class="mb-2">
        <label class="form-label">Mata Kuliah</label>
        <select name="id_matkul" class="form-control" required>
            <option value="">-- Pilih Mata Kuliah --</option>
            <?php foreach ($matkul as $m): ?>
                <option value="<?= $m['id_matkul'] ?>">
                    <?= $m['kode_matkul'] ?> - <?= $m['nama_matkul'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="mb-2">
        <label class="form-label">Judul Tugas</label>
        <input type="text" name="judul" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Deadline</label>
        <input type="datetime-local" name="deadline" class="form-control" required>
    </div>

    <button name="simpan" class="btn btn-primary">💾 Simpan Tugas</button>
    <a href="dashboard.php" class="btn btn-secondary">Batal</a>

</form>

</div>
</body>
</html>
