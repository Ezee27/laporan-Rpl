<?php
session_start();
include "../../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

// AMBIL SEMUA TUGAS
$stmt = $conn->query("
    SELECT 
        t.id_tugas,
        t.judul_tugas,
        t.deadline,
        mk.nama_matkul
    FROM tugas t
    JOIN mata_kuliah mk ON t.id_matkul = mk.id_matkul
    ORDER BY t.deadline ASC
");
$tugas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Daftar Tugas Dosen</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">

<h4 class="mb-3">📋 Daftar Tugas</h4>

<table class="table table-bordered">
<thead class="table-dark">
<tr>
    <th>No</th>
    <th>Mata Kuliah</th>
    <th>Judul Tugas</th>
    <th>Deadline</th>
    <th>Aksi</th>
</tr>
</thead>
<tbody>

<?php $no=1; foreach ($tugas as $t): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $t['nama_matkul'] ?></td>
    <td><?= $t['judul_tugas'] ?></td>
    <td><?= $t['deadline'] ?></td>
    <td>
        <a href="tugas_edit.php?id=<?= $t['id_tugas'] ?>" class="btn btn-sm btn-warning">
            ✏️ Edit
        </a>
        <a href="tugas_hapus.php?id=<?= $t['id_tugas'] ?>"
           onclick="return confirm('Yakin hapus tugas ini?')"
           class="btn btn-sm btn-danger">
            🗑️ Hapus
        </a>
    </td>
</tr>
<?php endforeach; ?>

</tbody>
</table>

<a href="dashboard.php" class="btn btn-secondary">⬅ Kembali</a>

</div>
</body>
</html>
