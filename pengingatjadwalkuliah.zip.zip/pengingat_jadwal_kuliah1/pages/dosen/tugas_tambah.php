<?php
session_start();
include "../../config/database.php";

// CEK DOSEN
if ($_SESSION['user']['role'] != 'dosen') {
    header("Location: ../../auth/login.php");
    exit;
}

// AMBIL DATA MATA KULIAH
$matkul = $conn->query("SELECT * FROM mata_kuliah")->fetchAll();

if (isset($_POST['simpan'])) {
    $id_matkul = $_POST['id_matkul'];
    $judul     = $_POST['judul'];
    $deadline  = $_POST['deadline'];

    $stmt = $conn->prepare("
        INSERT INTO tugas (id_matkul, judul_tugas, deadline)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$id_matkul, $judul, $deadline]);

    header("Location: tugas_list.php?status=success");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Tugas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">
<h4>📌 Tambah Tugas Baru</h4>

<form method="POST">
    <label class="mt-2">Mata Kuliah</label>
    <select name="id_matkul" class="form-control" required>
        <option value="">-- Pilih Mata Kuliah --</option>
        <?php foreach ($matkul as $m): ?>
            <option value="<?= $m['id_matkul'] ?>">
                <?= $m['nama_matkul'] ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label class="mt-2">Judul Tugas</label>
    <input type="text" name="judul" class="form-control" required>

    <label class="mt-2">Deadline</label>
    <input type="datetime-local" name="deadline" class="form-control" required>

    <button name="simpan" class="btn btn-primary mt-3">
        💾 Simpan Tugas
    </button>
</form>

</div>
</body>
</html>
