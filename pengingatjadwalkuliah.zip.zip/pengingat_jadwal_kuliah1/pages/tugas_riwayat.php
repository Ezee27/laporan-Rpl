<?php
session_start();
include "../config/database.php";

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}

$id_user  = $_SESSION['user']['id_user'];
$id_tugas = $_GET['id'] ?? null;

if (!$id_tugas) {
    header("Location: tugas.php");
    exit;
}

/* INFO TUGAS + MATA KULIAH */
$stmtInfo = $conn->prepare("
    SELECT 
        t.judul_tugas,
        t.deadline,
        mk.kode_matkul,
        mk.nama_matkul
    FROM tugas t
    JOIN mata_kuliah mk ON t.id_matkul = mk.id_matkul
    WHERE t.id_tugas = ?
");
$stmtInfo->execute([$id_tugas]);
$info = $stmtInfo->fetch();

if (!$info) {
    die("Data tugas tidak ditemukan");
}

/* RIWAYAT UPLOAD (PALING AMAN) */
$stmt = $conn->prepare("
    SELECT *
    FROM pengumpulan_tugas
    WHERE id_user = ? AND id_tugas = ?
");
$stmt->execute([$id_user, $id_tugas]);
$riwayat = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Tugas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<?php include "../partials/sidebar.php"; ?>

<div class="content">

<h3 class="mb-3">📂 Riwayat Pengumpulan Tugas</h3>

<div class="card mb-3">
    <div class="card-body">
        <b><?= $info['kode_matkul'] ?> - <?= $info['nama_matkul'] ?></b><br>
        <?= $info['judul_tugas'] ?><br>
        Deadline: <?= $info['deadline'] ?>
    </div>
</div>

<table class="table table-bordered bg-white">
<thead class="table-dark">
<tr>
    <th>No</th>
    <th>File</th>
    <th>Status</th>
</tr>
</thead>
<tbody>

<?php if (count($riwayat) == 0): ?>
<tr>
    <td colspan="3" class="text-center">Belum ada upload</td>
</tr>
<?php else: ?>
<?php $no = 1; foreach ($riwayat as $r): ?>

<?php
/* 
⚠️ GANTI nama_file SESUAI KOLOM FILE DI DATABASE KAMU
contoh:
$r['file']
$r['berkas']
$r['nama_file']
*/
$file = $r['nama_file'] ?? 'file_tidak_diketahui';

/* STATUS TANPA TANGGAL_UPLOAD */
$status = '<span class="badge bg-success">Terkumpul</span>';
?>

<tr>
    <td><?= $no++ ?></td>
    <td>
        <a href="../uploads/tugas/<?= $file ?>" target="_blank">
            <?= $file ?>
        </a>
    </td>
    <td><?= $status ?></td>
</tr>

<?php endforeach; endif; ?>

</tbody>
</table>

<a href="tugas.php" class="btn btn-secondary mt-3">⬅ Kembali</a>

</div>
</body>
</html>
