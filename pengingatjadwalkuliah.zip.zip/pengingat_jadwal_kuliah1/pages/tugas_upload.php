<?php
session_start();
include "../config/database.php";
if(!isset($_SESSION['user'])) exit;

$id_user=$_SESSION['user']['id_user'];
$id_tugas=$_GET['id'];

$tugas=$conn->prepare("SELECT * FROM tugas WHERE id_tugas=?");
$tugas->execute([$id_tugas]);
$data=$tugas->fetch();

if(isset($_POST['kirim'])){
$file=$_FILES['file']['name'];
$tmp=$_FILES['file']['tmp_name'];
$nama=time().'_'.$file;
move_uploaded_file($tmp,'../uploads/tugas/'.$nama);
$conn->prepare("INSERT INTO pengumpulan_tugas VALUES(NULL,?,?,?,NOW())")
->execute([$id_user,$id_tugas,$nama]);
header("Location: tugas.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Upload Tugas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include "../partials/sidebar.php"; ?>
<div class="content">
<h4>Upload Tugas</h4>
<p><b><?= $data['nama_matkul'] ?></b> - <?= $data['judul_tugas'] ?></p>
<form method="POST" enctype="multipart/form-data">
<input type="file" name="file" class="form-control mb-2" required>
<button name="kirim" class="btn btn-success">Kirim</button>
<a href="tugas.php" class="btn btn-secondary">Kembali</a>
</form>
</div>
</body>
</html>