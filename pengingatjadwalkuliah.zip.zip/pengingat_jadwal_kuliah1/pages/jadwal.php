<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Jadwal Kuliah</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<?php include "../partials/sidebar.php"; ?>

<div class="content">

<h3 class="mb-3">📅 Jadwal Kuliah</h3>
<p class="text-muted">Daftar jadwal perkuliahan semester berjalan</p>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered table-striped">
<thead class="table-primary text-center">
<tr>
<th>No</th>
<th>Kode</th>
<th>Mata Kuliah</th>
<th>SKS</th>
<th>Kelas</th>
<th>Ruangan</th>
<th>Dosen</th>
<th>Hari / Jam</th>
</tr>
</thead>

<tbody>
<tr>
<td>1</td>
<td>TIF306</td>
<td>Pemrograman Web 1</td>
<td>3</td>
<td>TI.24.A.4</td>
<td>B_4_B411<br>FT-FH</td>
<td>Agung Nugroho, S.Kom., M.Kom.</td>
<td>Kamis<br>12.30 – 15.00</td>
</tr>

<tr>
<td>2</td>
<td>TIF303</td>
<td>Rekayasa Perangkat Lunak</td>
<td>3</td>
<td>TI.24.A.4</td>
<td>B_5_B517<br>FT-FH</td>
<td>Karina Imelda, S.Kom., M.Kom.</td>
<td>Senin<br>12.30 – 15.00</td>
</tr>

<tr>
<td>3</td>
<td>TIF307</td>
<td>Jaringan Komputer</td>
<td>3</td>
<td>TI.24.A.4</td>
<td>B_4_B424<br>FT-FH</td>
<td>Ahmad Turmudi, Zy, S.Kom., M.Kom.</td>
<td>Selasa<br>09.31 – 12.00</td>
</tr>

<tr>
<td>4</td>
<td>TIF304</td>
<td>Pemrograman Orientasi Objek</td>
<td>3</td>
<td>TI.24.A.4</td>
<td>B_4_B411<br>FT-FH</td>
<td>Nawangsih, S.</td>
<td>Senin<br>09.31 – 12.00</td>
</tr>

<tr>
<td>5</td>
<td>TIF302</td>
<td>Probabilitas dan Statistika</td>
<td>3</td>
<td>TI.24.A.4</td>
<td>B_4_B411<br>FT-FH</td>
<td>Ir. U. Darmanto Soer, M.Kom.</td>
<td>Senin<br>07.00 – 09.30</td>
</tr>

<tr>
<td>6</td>
<td>UPB301</td>
<td>Pendidikan Agama 3</td>
<td>1</td>
<td>TI.24.A.4</td>
<td>B_4_B424<br>FT-FH</td>
<td>Mustafa Al Mujahidin Al</td>
<td>Selasa<br>07.00 – 09.30</td>
</tr>

<tr>
<td>7</td>
<td>TIF305</td>
<td>Pemrograman Mobile 1</td>
<td>4</td>
<td>TI.24.A.4</td>
<td>B_4_B418<br>FT-FH</td>
<td>Donny Maulana, S.Kom., M.M.S.I.</td>
<td>Kamis<br>09.31 – 12.00</td>
</tr>
</tbody>

</table>

</div>
</div>

</div>

</body>
</html>
