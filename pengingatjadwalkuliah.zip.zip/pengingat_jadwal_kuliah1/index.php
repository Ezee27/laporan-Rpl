<?php
session_start();

// kalau sudah login → dashboard
if (isset($_SESSION['user'])) {
    header("Location: pages/dashboard.php");
    exit;
}

// kalau belum login → login page
header("Location: auth/login.php");
exit;
