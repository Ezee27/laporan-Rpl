<link rel="stylesheet" href="../assets/css/style.css">
<div class="sidebar">
<h4 class="text-center py-3">Pengingat Kuliah</h4>
<a href="dashboard.php">Dashboard</a>
<a href="jadwal.php">Jadwal</a>
<a href="tugas.php">Tugas</a>
<a href="../pages/pengingat.php">Pengingat</a>
<a href="../auth/logout.php">Logout</a>
</div>