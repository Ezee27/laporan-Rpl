<?php
session_start();
include "../config/database.php";

if (isset($_POST['register'])) {

    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $password = md5($_POST['password']);

    // DEFAULT ROLE
    $role = 'mahasiswa';

    // CEK EMAIL SUDAH ADA ATAU BELUM
    $cek = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $cek->execute([$email]);

    if ($cek->rowCount() > 0) {
        $error = "Email sudah terdaftar!";
    } else {

        // INSERT SESUAI JUMLAH KOLOM
        $stmt = $conn->prepare("
            INSERT INTO users (nama, email, password, role)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$nama, $email, $password, $role]);

        header("Location: login.php?register=success");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Register</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-success d-flex justify-content-center align-items-center" style="height:100vh">

<div class="card shadow" style="width:380px">
<div class="card-body">

<h4 class="text-center mb-3">📝 Register</h4>

<?php if(isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">
    <input type="text" name="nama" class="form-control mb-2" placeholder="Nama Lengkap" required>
    <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
    <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

    <button type="submit" name="register" class="btn btn-success w-100">
        Daftar
    </button>
</form>

<hr>

<a href="login.php" class="d-block text-center text-decoration-none">
    🔐 Sudah punya akun? Login
</a>

</div>
</div>

</body>
</html>
