<?php
session_start();
include "../config/database.php";

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
    $stmt->execute([$email, $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $_SESSION['user'] = $user;

        // 🔀 REDIRECT BERDASARKAN ROLE
        if ($user['role'] === 'dosen') {
            header("Location: ../pages/dosen/dashboard.php");
        } else {
            header("Location: ../pages/dashboard.php");
        }
        exit;
    } else {
        $error = "Email atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-primary d-flex justify-content-center align-items-center" style="height:100vh">

<div class="card shadow" style="width:360px">
<div class="card-body">

<h4 class="text-center mb-3">🔐 Login</h4>

<?php if(isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">
    <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
    <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>

    <button type="submit" name="login" class="btn btn-primary w-100">
        Login
    </button>
</form>

<hr>

<!-- ✅ LINK REGISTER (INI YANG TADI HILANG) -->
<a href="../auth/register.php" class="d-block text-center text-decoration-none">
    ➕ Daftar akun baru
</a>

</div>
</div>

</body>
</html>
